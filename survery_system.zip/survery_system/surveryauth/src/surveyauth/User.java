package surveyauth;

import org.mindrot.jbcrypt.BCrypt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class User {
    public static boolean signup(String username, String email, String password) {
        // Validation
        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            return false;
        }
        if (!isValidEmail(email)) {
            return false;
        }
        if (!isValidPassword(password)) {
            return false;
        }

        // Encrypt password
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        // Store in database
        String query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, email.toLowerCase()); // Store email in lowercase
            stmt.setString(3, hashedPassword);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Signup SQL Error: " + e.getMessage());
            return false;
        }
    }

    public static boolean login(String email, String password) {
        if (email.isEmpty() || password.isEmpty()) {
            System.err.println("Login Error: Email or password is empty");
            return false;
        }

        String query = "SELECT password FROM users WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email.toLowerCase()); // Query email in lowercase
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String hashedPassword = rs.getString("password");
                if (hashedPassword == null) {
                    System.err.println("Login Error: No password found for email: " + email);
                    return false;
                }
                boolean passwordMatch = BCrypt.checkpw(password, hashedPassword);
                if (!passwordMatch) {
                    System.err.println("Login Error: Password does not match for email: " + email);
                }
                return passwordMatch;
            } else {
                System.err.println("Login Error: Email not found: " + email);
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Login SQL Error: " + e.getMessage());
            return false;
        }
    }

    public static boolean forgotPassword(String email) {
        String query = "SELECT username FROM users WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email.toLowerCase());
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("Forgot Password SQL Error: " + e.getMessage());
            return false;
        }
    }

    public static int getUserId(String email) {
        String query = "SELECT id FROM users WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email.toLowerCase());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
            System.err.println("GetUserId Error: Email not found: " + email);
            return -1;
        } catch (SQLException e) {
            System.err.println("GetUserId SQL Error: " + e.getMessage());
            return -1;
        }
    }

    private static boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    private static boolean isValidPassword(String password) {
        return password.length() >= 8 &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*].*");
    }
}