package surveyauth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class Survey {
    public static boolean submitSurvey(int userId, String name, int age, String gender, int satisfaction,
                                      String suggestions, String programmingLanguage, String favoriteIde, String feedback) {
        // Validation
        if (name.isEmpty() || gender.isEmpty()) {
            return false;
        }
        if (age < 1 || age > 120) {
            return false;
        }
        if (satisfaction < 1 || satisfaction > 5) {
            return false;
        }

        String query = "INSERT INTO surveys (user_id, name, age, gender, satisfaction, suggestions, programming_language, favorite_ide, feedback, submission_date) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setString(2, name);
            stmt.setInt(3, age);
            stmt.setString(4, gender);
            stmt.setInt(5, satisfaction);
            stmt.setString(6, suggestions);
            stmt.setString(7, programmingLanguage);
            stmt.setString(8, favoriteIde);
            stmt.setString(9, feedback);
            stmt.setDate(10, java.sql.Date.valueOf(LocalDate.now()));
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}