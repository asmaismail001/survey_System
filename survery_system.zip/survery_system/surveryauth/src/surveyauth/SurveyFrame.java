package surveyauth;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SurveyFrame extends JFrame {
    private JTextField emailField, nameField, ageField, programmingLanguageField, favoriteIdeField;
    private JComboBox<String> genderComboBox, satisfactionComboBox;
    private JTextArea suggestionsArea, feedbackArea;

    public SurveyFrame() {
        setTitle("Survey Form");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Custom panel with gradient background
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, new Color(100, 181, 246), 0, getHeight(), new Color(33, 150, 243));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Scrollable content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridBagLayout());
        contentPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Title
        JLabel titleLabel = new JLabel("Student Feedback Survey", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 20, 10);
        contentPanel.add(titleLabel, gbc);

        // Form fields
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        emailLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(5, 10, 0, 10);
        contentPanel.add(emailLabel, gbc);

        emailField = createStyledTextField();
        gbc.gridx = 0;
        gbc.gridy = 2;
        contentPanel.add(emailField, gbc);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(nameLabel, gbc);

        nameField = createStyledTextField();
        gbc.gridx = 0;
        gbc.gridy = 4;
        contentPanel.add(nameField, gbc);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        ageLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(ageLabel, gbc);

        ageField = createStyledTextField();
        gbc.gridx = 0;
        gbc.gridy = 6;
        contentPanel.add(ageField, gbc);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        genderLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(genderLabel, gbc);

        genderComboBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 8;
        contentPanel.add(genderComboBox, gbc);

        JLabel satisfactionLabel = new JLabel("Satisfaction (1-5):");
        satisfactionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        satisfactionLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(satisfactionLabel, gbc);

        satisfactionComboBox = new JComboBox<>(new String[]{"1", "2", "3", "4", "5"});
        satisfactionComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 10;
        contentPanel.add(satisfactionComboBox, gbc);

        JLabel suggestionsLabel = new JLabel("Suggestions:");
        suggestionsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        suggestionsLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 11;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(suggestionsLabel, gbc);

        suggestionsArea = new JTextArea(3, 20);
        suggestionsArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        suggestionsArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        gbc.gridx = 0;
        gbc.gridy = 12;
        contentPanel.add(new JScrollPane(suggestionsArea), gbc);

        JLabel programmingLanguageLabel = new JLabel("Preferred Programming Language:");
        programmingLanguageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        programmingLanguageLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 13;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(programmingLanguageLabel, gbc);

        programmingLanguageField = createStyledTextField();
        gbc.gridx = 0;
        gbc.gridy = 14;
        contentPanel.add(programmingLanguageField, gbc);

        JLabel favoriteIdeLabel = new JLabel("Favorite IDE:");
        favoriteIdeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        favoriteIdeLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 15;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(favoriteIdeLabel, gbc);

        favoriteIdeField = createStyledTextField();
        gbc.gridx = 0;
        gbc.gridy = 16;
        contentPanel.add(favoriteIdeField, gbc);

        JLabel feedbackLabel = new JLabel("Additional Feedback:");
        feedbackLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        feedbackLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 17;
        gbc.insets = new Insets(10, 10, 0, 10);
        contentPanel.add(feedbackLabel, gbc);

        feedbackArea = new JTextArea(3, 20);
        feedbackArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        feedbackArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        gbc.gridx = 0;
        gbc.gridy = 18;
        contentPanel.add(new JScrollPane(feedbackArea), gbc);

        // Buttons
        JButton submitButton = createStyledButton("Submit");
        JButton cancelButton = createStyledButton("Cancel");

        // Button actions
        submitButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String name = nameField.getText().trim();
            String ageStr = ageField.getText().trim();
            String gender = (String) genderComboBox.getSelectedItem();
            String satisfactionStr = (String) satisfactionComboBox.getSelectedItem();
            String suggestions = suggestionsArea.getText().trim();
            String programmingLanguage = programmingLanguageField.getText().trim();
            String favoriteIde = favoriteIdeField.getText().trim();
            String feedback = feedbackArea.getText().trim();

            if (email.isEmpty() || name.isEmpty() || ageStr.isEmpty() || gender.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Email, Name, Age, and Gender are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int userId = User.getUserId(email);
            if (userId == -1) {
                JOptionPane.showMessageDialog(this, "User not found. Please signup or login first.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int age;
            try {
                age = Integer.parseInt(ageStr);
                if (age < 1 || age > 120) {
                    JOptionPane.showMessageDialog(this, "Invalid age.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid age format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int satisfaction = Integer.parseInt(satisfactionStr);

            if (Survey.submitSurvey(userId, name, age, gender, satisfaction, suggestions, programmingLanguage, favoriteIde, feedback)) {
                JOptionPane.showMessageDialog(this, "Survey submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Survey submission failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelButton.addActionListener(e -> dispose());

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        gbc.gridx = 0;
        gbc.gridy = 19;
        gbc.insets = new Insets(20, 10, 10, 10);
        contentPanel.add(buttonPanel, gbc);

        // Add content panel to scroll pane
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        panel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(panel);
    }

    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        return field;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(new Color(33, 150, 243));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(66, 165, 245));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(33, 150, 243));
            }
        });

        return button;
    }
}