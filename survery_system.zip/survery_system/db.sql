CREATE DATABASE survey_auth_db;
USE survey_auth_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE surveys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(10) NOT NULL,
    satisfaction INT NOT NULL,
    suggestions TEXT,
    programming_language VARCHAR(50),
    favorite_ide VARCHAR(50),
    feedback TEXT,
    submission_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);